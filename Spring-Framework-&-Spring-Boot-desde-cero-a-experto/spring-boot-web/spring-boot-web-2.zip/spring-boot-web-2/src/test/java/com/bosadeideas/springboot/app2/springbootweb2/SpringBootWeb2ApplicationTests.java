package com.bosadeideas.springboot.app2.springbootweb2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWeb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
